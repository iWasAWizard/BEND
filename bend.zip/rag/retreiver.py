from fastapi import FastAPI, UploadFile, File
from pydantic import BaseModel
from qdrant_client import QdrantClient
from qdrant_client.http.models import VectorParams, Distance, PointStruct
from sentence_transformers import SentenceTransformer
import os, uuid, shutil

app = FastAPI()

client = QdrantClient(host="qdrant", port=6333)
model = SentenceTransformer("all-MiniLM-L6-v2")
COLLECTION = "bend-docs"

client.recreate_collection(
    collection_name=COLLECTION,
    vectors_config=VectorParams(
        size=model.get_sentence_embedding_dimension(),
        distance=Distance.COSINE,
    )
)

def embed_file(path):
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    chunks = [text[i:i+500] for i in range(0, len(text), 500)]
    vectors = model.encode(chunks).tolist()
    points = [
        PointStruct(id=str(uuid.uuid4()), vector=vec, payload={"text": chunk})
        for vec, chunk in zip(vectors, chunks)
    ]
    client.upsert(collection_name=COLLECTION, points=points)

@app.post("/ingest")
async def ingest_doc(file: UploadFile = File(...)):
    dest_path = f"docs/{file.filename}"
    with open(dest_path, "wb") as f:
        shutil.copyfileobj(file.file, f)
    embed_file(dest_path)
    return {"message": f"{file.filename} ingested successfully"}

class QueryRequest(BaseModel):
    query: str
    top_k: int = 5

@app.post("/retrieve")
def retrieve(req: QueryRequest):
    vec = model.encode(req.query).tolist()
    hits = client.search(collection_name=COLLECTION, query_vector=vec, limit=req.top_k)
    return [hit.payload["text"] for hit in hits]

