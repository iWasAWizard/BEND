from fastapi import FastAPI, UploadFile, File
from pydantic import BaseModel
import requests

app = FastAPI()

@app.post("/transcribe")
async def transcribe(file: UploadFile = File(...)):
    files = {"file": (file.filename, await file.read())}
    response = requests.post("http://whisper:9000/transcribe", files=files)
    return response.json()

class SpeakRequest(BaseModel):
    text: str

@app.post("/speak")
def speak(data: SpeakRequest):
    response = requests.post("http://piper:59125/api/tts", json={"text": data.text})
    return response.content

