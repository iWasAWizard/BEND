```markdown
# BEND  
**Backend Enhanced Neural Dispatch**

BEND is a locally-hosted, containerized intelligence stack built to run high-performance LLMs, whispering STT, cloned TTS, and full RAG pipelines.  
It’s for when you want a fast, self-sufficient brainstem that does more than just answer questions—it listens, speaks, remembers, and swaps personalities on command.

> It's like ChatGPT moved into your server closet and brought a filing cabinet.

---

## 🚀 Features

- **KoboldCPP** backend (GGUF & EXL2 models)
- **Hot-swappable models** via `models.yaml`
- **Speech-to-text** via Whisper
- **Text-to-speech** via Piper
- **Unified voice proxy API** (`/speak`, `/transcribe`)
- **Document RAG system** (FastAPI + Qdrant)
- **OpenWebUI** frontend
- **Fully Dockerized** and rebuildable from scratch

---

## 📁 Project Structure

```
bend/
├── models.yaml              # Canonical model registry
├── docker-compose.yml       # All services, one file
├── .env                     # Auto-generated model link
├── scripts/                 # Utility scripts (optional move)
├── models/                  # GGUF + EXL2 model files
├── audio/                   # Whisper scratchpad
├── piper/                   # Voice model volume
├── rag-stack/               # RAG API + vector database
│   ├── retriever.py
│   ├── Dockerfile
│   └── docs/
```

---

## 🛠️ Setup

### 1. Install Dependencies

```bash
brew install yq       # macOS
sudo snap install yq  # Linux
```

### 2. Clone + Configure

```bash
git clone https://github.com/yourname/bend
cd bend
cp .env.example .env
```

### 3. Bootstrap the Stack

```bash
./scripts/switch-model.sh hermes         # Or: mythomax, deepseek, rpbeagle
docker compose up -d --build
```

---

## 📞 API Endpoints

| Endpoint         | Description                    |
|------------------|--------------------------------|
| `POST /speak`    | Input text → Returns audio     |
| `POST /transcribe` | Input audio → Returns text    |
| `POST /ingest`   | Upload .txt or .md for RAG     |
| `POST /retrieve` | Query your documents           |

---

## 🔄 Scripts

| Script            | Purpose                              |
|-------------------|--------------------------------------|
| `switch-model.sh` | Switch model by key from `models.yaml` |
| `rebuild.sh`      | Tear down & rebuild full stack       |
| `list-models.sh`  | Pretty print all model options       |
| `healthcheck.sh`  | Check which services are up          |

---

## ✨ Example: Voice In, Voice Out

```bash
curl -X POST http://localhost:12008/speak \
  -H "Content-Type: application/json" \
  -d '{"text": "Welcome to BEND. Let’s get to work."}'
```

---

## 🤖 Example: Query Your Uploaded Docs

```bash
curl -X POST http://localhost:12007/retrieve \
  -H "Content-Type: application/json" \
  -d '{"query": "how do I restart the stack?"}'
```

---

## 🧠 Model Registry (`models.yaml`)

All supported models live here. To add new ones, just extend the file:

```yaml
- key: yourmodel
  name: Your Custom Model
  filename: your-model-name.gguf
  quant: Q5_K_M
  context: 8K
  use_case: creative writing
  url: https://huggingface.co/YourUser/YourModel/resolve/main/model.gguf
```

---

## 🧼 Reset Everything

```bash
./rebuild.sh
```

Wipes containers, volumes, restarts with current model + endpoints.

---

## 📈 Monitoring

Visit `http://localhost:12005` for Glances dashboard (system stats, container load, memory usage, etc.)

---

## 🎯 Ports

| Port   | Service      |
|--------|--------------|
| 12002  | OpenWebUI    |
| 12003  | Whisper STT  |
| 12004  | Piper TTS    |
| 12005  | Glances      |
| 12006  | Qdrant (RAG) |
| 12007  | Retriever API|
| 12008  | Voice Proxy  |
| 12009  | KoboldCPP    |

---

## 💬 Philosophy

BEND is designed to be:
- **Modular** – swap pieces in/out
- **Reproducible** – bootstrap cleanly, rebuild reliably
- **Self-hosted** – no cloud, no SaaS, just horsepower
- **Expandable** – perfect core for agent stacks like AEGIS

---

## 🧪 Status

BEND is stable and deployable. It is also:
- Curious
- Loud
- Excellent at solving your problems and/or creating new ones

> “You don’t build a backend like this for fun.  
> You build it because **you want the machine to talk back.**”
```

