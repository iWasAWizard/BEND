#!/bin/bash
# switch-model.sh - BEND's unified GGUF model selector

set -e

MODEL_KEY="$1"
MODELS_FILE="models.yaml"
MODELS_DIR="./models"

if [ -z "$MODEL_KEY" ]; then
  echo "Usage: ./switch-model.sh <model-key>"
  echo "Available keys:"
  yq e '.models[].key' "$MODELS_FILE"
  exit 1
fi

MODEL_NAME=$(yq e ".models[] | select(.key == \"$MODEL_KEY\") | .filename" "$MODELS_FILE")
MODEL_URL=$(yq e ".models[] | select(.key == \"$MODEL_KEY\") | .url" "$MODELS_FILE")
MODEL_HUMAN=$(yq e ".models[] | select(.key == \"$MODEL_KEY\") | .name" "$MODELS_FILE")

if [ -z "$MODEL_NAME" ] || [ "$MODEL_NAME" == "null" ]; then
  echo "[-] Model key \"$MODEL_KEY\" not found in $MODELS_FILE"
  exit 1
fi

MODEL_PATH="$MODELS_DIR/$MODEL_NAME"

if [ ! -f "$MODEL_PATH" ]; then
  echo "[!] Model file not found: $MODEL_PATH"
  echo "[+] Downloading: $MODEL_HUMAN"
  mkdir -p "$MODELS_DIR"
  curl -L "$MODEL_URL" -o "$MODEL_PATH"
  echo "[✓] Download complete."
fi

echo "[+] Setting MODEL_NAME=$MODEL_NAME"
echo "MODEL_NAME=$MODEL_NAME" > .env

echo "[*] Restarting koboldcpp..."
docker compose restart koboldcpp
echo "[✓] Switched to: $MODEL_HUMAN ($MODEL_NAME)"

