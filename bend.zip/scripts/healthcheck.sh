#!/bin/bash
# healthcheck.sh - Check all exposed BEND services

declare -A services=(
  ["koboldcpp"]="http://localhost:12009"
  ["openwebui"]="http://localhost:12002"
  ["whisper"]="http://localhost:12003"
  ["piper"]="http://localhost:12004"
  ["glances"]="http://localhost:12005"
  ["qdrant"]="http://localhost:12006"
  ["retriever"]="http://localhost:12007"
  ["voiceproxy"]="http://localhost:12008"
)

echo "🩺 BEND Health Check:"
for svc in "${!services[@]}"; do
  url="${services[$svc]}"
  if curl -s --head --request GET "$url" | grep "200 OK" > /dev/null; then
    echo "✅ $svc is up at $url"
  else
    echo "❌ $svc failed at $url"
  fi
done

